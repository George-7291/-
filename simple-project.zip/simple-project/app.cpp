
#include "app.h"


void main_task(intptr_t unused) {
    ext_tsk();
}
// end::main_task[]
